import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-gYZ10BP7.js";import"./index.vue_vue_type_script_setup_true_lang-Dq4TPpm1.js";import"./index-CbUjpH5D.js";export{o as default};
