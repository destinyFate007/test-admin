import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DKFJCXgA.js";import"./index-656TmsM9.js";import"./index-CbUjpH5D.js";export{o as default};
