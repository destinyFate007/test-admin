import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D-9AUfAR.js";import"./index.vue_vue_type_script_setup_true_lang-rjnwoPCM.js";import"./index-CbUjpH5D.js";export{o as default};
