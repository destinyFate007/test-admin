import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CzbrYMl5.js";import"./index-52s4Ys0D.js";import"./index-CbUjpH5D.js";export{o as default};
