import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-C6MHKmx4.js";import"./index.vue_vue_type_script_setup_true_lang-DqSzN_vr.js";import"./index-CbUjpH5D.js";export{o as default};
