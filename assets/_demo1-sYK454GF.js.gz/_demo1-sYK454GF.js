import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DavU7vH3.js";import"./index-CSPfta8_.js";import"./index-CbUjpH5D.js";export{o as default};
