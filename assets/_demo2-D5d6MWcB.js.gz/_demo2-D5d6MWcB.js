import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BZN7DCVD.js";import"./index-52s4Ys0D.js";import"./index-CbUjpH5D.js";export{o as default};
