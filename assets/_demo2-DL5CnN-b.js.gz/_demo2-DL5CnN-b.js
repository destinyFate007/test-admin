import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DwRM5Jpm.js";import"./index-dTNE1ODw.js";import"./index-CbUjpH5D.js";export{o as default};
