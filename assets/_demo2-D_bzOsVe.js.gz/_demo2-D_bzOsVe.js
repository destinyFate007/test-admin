import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-lT5FiuSl.js";import"./index.vue_vue_type_script_setup_true_lang-Dq4TPpm1.js";import"./index-CbUjpH5D.js";export{o as default};
