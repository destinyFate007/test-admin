import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-xoqwQCea.js";import"./index-CbUjpH5D.js";import"./index-D5PPROsD.js";export{o as default};
