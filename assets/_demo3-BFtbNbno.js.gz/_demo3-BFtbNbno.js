import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-B4xo6VXL.js";import"./index.vue_vue_type_script_setup_true_lang-BFacqqHB.js";import"./index-CbUjpH5D.js";export{o as default};
