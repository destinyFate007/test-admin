import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-7NZIFnmY.js";import"./index.vue_vue_type_script_setup_true_lang-BvI5DOsQ.js";import"./index-CbUjpH5D.js";export{o as default};
