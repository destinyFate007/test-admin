import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DJkcf4a6.js";import"./index.vue_vue_type_script_setup_true_lang-G22qHAk6.js";import"./index-CbUjpH5D.js";export{o as default};
