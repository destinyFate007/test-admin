import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Cl0x1qbr.js";import"./index.vue_vue_type_script_setup_true_lang-G22qHAk6.js";import"./index-CbUjpH5D.js";export{o as default};
