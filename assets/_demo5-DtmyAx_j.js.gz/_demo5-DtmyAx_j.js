import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BN3W4Z93.js";import"./index-CbUjpH5D.js";import"./index.vue_vue_type_script_setup_true_lang-DZyaDe6a.js";export{o as default};
