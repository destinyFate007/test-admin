import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-Byt6jX0d.js";import"./index.vue_vue_type_script_setup_true_lang-G22qHAk6.js";import"./index-CbUjpH5D.js";export{o as default};
