import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_7Mf80e.js";import"./index-CbUjpH5D.js";import"./roleExample-f5qLXM1n.js";export{o as default};
