import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-H1kUMy0X.js";import"./index-CbUjpH5D.js";import"./dictionaryExample-Bzel3FlN.js";export{o as default};
