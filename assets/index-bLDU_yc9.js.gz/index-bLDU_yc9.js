import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B8h-1v50.js";import"./index-CbUjpH5D.js";import"./departmentExample-DU4OXOSZ.js";export{o as default};
