import{M as r,bk as t,bl as u}from"./index-CbUjpH5D.js";function s(o){return r(()=>{var e;return t(o)?!!((e=u(o))!=null&&e.closest("form")):!0})}export{s as u};
